# Rusk Recovery Asset Pack

Prepared for RuneSpace issue #190.

## Included final production-ready files

- `public/location-scenes/rusk-recovery.webp`
  - main Rusk Recovery location scene
  - exact 4:1 derivative
  - exported at 1536x384 WebP

- `public/location-scenes/rusk-recovery-dialogue.webp`
  - Rusk Recovery dialogue background
  - exact 15:8 derivative
  - exported at 1710x912 WebP

- `public/map-icons/rusk-recovery.webp`
  - Rusk Recovery map identifier
  - chroma-key pink removed, converted to grayscale after cleanup
  - tightly trimmed, transparent, lossless WebP
  - delivered at 512x230

- `public/item-art/scrap-metal.webp`
  - Scrap Metal item art
  - chroma-key pink removed
  - transparent lossless WebP

## Included master/source files

The `masters/` directory contains the approved source generations used to prepare the game-ready derivatives.

## Notes for Claude

- Treat these as approved production assets. Do not regenerate them.
- Wire them into the implementation for issue #190.
- Use the delivered finals under the `public/` paths above.

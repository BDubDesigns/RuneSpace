# RuneSpace — Holo Hollow Environment / Background Handoff

Implementation-ready approved art package. Approved scene art is **not upscaled**; native dimensions are preserved.

## Final runtime-ready assets

### Map identifier
- `holo-hollow-map-identifier.webp` — 512×430, transparent grayscale, lossless WebP, tight alpha crop

### 4:1 location ultrawides — native 1536×384
- `holo-hollow-town-overview-ultrawide.webp`
- `holo-hollow-souvenirs-mining-supplies-exterior-ultrawide.webp`
- `hh-bnb-exterior-ultrawide.webp`
- `community-assistance-center-exterior-ultrawide.webp`

### Dialogue backgrounds — native 1536×864
- `holo-hollow-souvenirs-mining-supplies-interior-dialogue-bg.webp` — Bix
- `community-assistance-center-interior-dialogue-bg.webp` — Renn
- `hh-bnb-interior-dialogue-bg.webp` — Mara / immediate follow-up slice

## Handoff rules
- Do not regenerate or upscale approved art.
- Follow current `main` for exact repository paths/content definitions rather than inventing a parallel asset contract.
- Record true intrinsic dimensions.
- Verify responsive object-cover crops/focals in the actual RuneSpace UI before committing final metadata.
- Mara/B&B interior is available early but does not broaden Issue #159 scope.

See `manifest.json` for recommended alt text, usage mapping, dimensions, and focal metadata. `source-uploads/` preserves the source PNGs.
